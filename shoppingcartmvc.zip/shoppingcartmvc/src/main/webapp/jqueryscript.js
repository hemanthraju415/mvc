function addtocart(bu)
{
	var id=$(bu).parent().parent().attr('id');
	var name;
	var price;
	var img;
	$(bu).parent().each(function(i)
	{
		if(i==0)
		{
			console.log($(this).text());
			
		}
		console.log($(this).text());
		
	})
	$(bu).parent().parent().each(function(i)
	{
		
		console.log(i+"==>"+$(this).children().text());
		
	})
	/*$(bu).parent().parent().each(function(j){
		
		if($(this).children().children().is('img'))
		{
			img=$(this).children().children().attr('src');
		}
		else if($(this).children().attr('class')=="desc")
		{
			console.log(true)
			name=$(this).children().children().text();
		}
		else
		{
			price=name=$(this).children().children().text();
		}
	})
	console.log(id,name,price,img);
	
	
	$(bu).parent().parent().each(function(i)
	{
		console.log($(this).text());
		console.log($(this).attr('src'));	
		console.log($(this).id);
	})*/
}