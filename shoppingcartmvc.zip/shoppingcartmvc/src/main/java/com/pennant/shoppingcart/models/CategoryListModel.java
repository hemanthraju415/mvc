package com.pennant.shoppingcart.models;

import java.util.ArrayList;

public class CategoryListModel extends ArrayList<CategoryModel> {
	private static final long serialVersionUID = 194464732632345446L;

}
